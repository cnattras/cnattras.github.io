#!/usr/bin/perl
#unless($#ARGV==0){
#print "Wrong number of parameters.\n";
#die;
#}






#summary of names of variables
#these are declared here so that they will be defined outside of the subroutines
#$fullname[]  array with full names of students
$fullname[0]=0;
#$firstname[]  array with first name of students
$firstname[0]=0;
#$lastname[]  array of last names
$lastname[0]=0;
#$numstudents  number of students, counting starts at 1
$numstudents=0;

#$partofgrade[]  array with the names of the parts of the grade in it (like lab notebookes, quizzes
$partofgrade[0]=0;
#$weight[]  array with the weights of the different parts of the grade (in percentages or relativeweights -- these are renormalized)
$weight[0]=0;
#$gradeoutof[]  array with the number of points that the grade was given out of
$gradeoutof[0]=0;
#$relativeweight[]  array with the relative weight of each part of the grade
$relativeweight[0]=0;

#$boolAverage[]  contains a 1 if there was an average recorded in the grade sheet and a 0 if there wasn't so that I know whether or not to count the last column
$boolAverage[0]=0;
#$names[part of grade][] array with the headings for the parts of the grade


$names[0][0]=0;
#$numberofnames[part of grade] array with the number of headings for the parts of the grade
$numberofnames[0]=0;
#$numpartsofgrade the number of different parts of the grade there are, counting starts with 1
$numpartsofgrade=0;
#$gradepart -- variable which contains the name of the grades which are currently being read
$gradepart = "";
#$numgradepart -- variable which contains the number of the part of the grade which is being read
$numgradepart=-1;

#$grades[student number][part of grade][] array with student grades
$grades[0][0][0]=0;
#$pointspossible[part of grade][assignment number]
$pointspossible[0][0]=0;
#$pointspossiblestrings[part of grade] -- storage of the lines with the points possible.  I have to fill the points possible array after I have read all of the lines in the input file because that's when I know how many grades there are so I store the strings here until I know enough to get info out of them
$pointspossiblestrings[0]="";
#$boolPointsPossibleInitialized -- keeps track of whether or not the number of points possible array has been initialize, ie, have the entries been filled with the default number of entries for that type of entries.  If it has been done, it won't be done again.
$boolPointsPossibleInitialized=0;
#$studentavggrades[student number][part of grade] array with average grades
$studentavggrades[0][0]=0;
#$classavggrades[part of grade][assignment number] array with average grades
$classavggrades[0][0]=0;
#$classptofgradeavg[part of grade]  array with the average in the class of each part of the grade
$classptofgradeavg[0]=0;
#$studentweightedavg[student number]
$studentweightedavg[0]=0;
#$classweightedavg -- the average weighted average
$classweightedavg=0;
#$classweightedstddev -- the average weighted average standard deviation
$classweightedstddev=0;
#note that the below have the standard deviation calculated with the grades students recieved considered as measurements of their ability so that each grade is considered a sample of their ability.  Then the number of possible samples of their ability is in principle infinite and we are calculating s, an approximation of the standard deviation based on a limited sample size.  (The denominator under the sum is n-1.)
#The other alternative would be to calculate the standard deviation of the grades that students actually obtained.  Then we have all possible measurements and the denominator would be n.
#Since I find it more useful to think of this as a measurement of a student's ability, I have calculated it in the former way, estimating the standard deviation of this measure of the student's ability.
#$studentstddev[student number][part of grade] array with average grades
$studentstddev[0][0]=0;
#$classstddev[part of grade][assignment number] array with average grades
$classstddev[0][0]=0;
#$classptofgradestddev[part of grade] array with std dev of student averages
$classptofgradestddev[0]=0;

#These arrays with the student ranks have an additional entry at $numstudents+2 with the number of entries in this array
#$partofgraderanks[$studentnumber][$partofgrade] array with each student's rank for each part of the grade
$partofgraderanks[0][0]=0;
#$assignmentranks[$student number][$part of grade][$assignmentnumber] array with each student's rank for each assignment for each part of the grade
$assignmentranks[0][0][0]=0;
#$weightedavggraderanks[$student number] array with students' ranks for weighted grades
$weightedavggraderanks[0]=0;

#My dummy variables which I actually want defined outside of the scope of the loops
#In practice I don't think I used these outside of their respective loops but I didn't feel like checking code that is working if I deleted this crap
$i=0;
$j=0;
$k=0;




#summary of subroutines:


#Main:
&RetrieveStudentNames();
#&CheckFullnames();
#&CheckFirstnames();
#&CheckLastnames();
&RetrievePartsOfGrade();
#&CheckPartsOfGrade();
#&EchoNumgrades();
&Grade();
#&CheckNumberOfNames();
#&CheckNamesOfAssignments();
#&CheckGrades();

&SetPointsPossible();
#&CheckPointsPossible();
#End Main.
&CalculateStudentAverages();
#&CheckStudentAverages();
&CalculateClassAverages();
#&CheckClassAverages();
&CalculateClassPartOfGradeAverages();
#&CheckClassPartOfGradeAverages();
&CalculateClassPartOfGradeStdDev();
#&CheckClassPartOfGradeStdDev();
&CalculateStudentStdDev();
#&CheckStudentStdDev();
&CalculateClassStdDev();
#&CheckClassStdDev();
&CalculateStudentWeightedAverage();
#&CheckStudentWeightedAverage();
&CalculateClassWeightedAverage();
&CalculateClassWeightedStdDev();
#&CheckClassWeightedAverageAndStdDev();

&RankWeightedGrades();
#&CheckWeightedGradeRanks();
&RankPartsOfGrades();
#&CheckPartsOfGradesRanks();
&RankAssignmentGrades();
#&CheckAssignmentRanks();

&WriteSummaryWebpage();
&WriteStudentSummaryWebpages();

sub RetrieveStudentNames {
  #Getting list of student grades
  open (STUDENTLIST, "<StudentList.txt") || die "Can't open configuration file StudentList.txt.\n";
  print "Retrieving student names.  I will calculate the grades for the following students:\n";
  $i=0;
  while(<STUDENTLIST>)
    {
      $line=$_;
      ($fullname[$i],$garb)=split("\n",$line);
      $nametemp=$fullname[$i];
      ($lastname[$i],$garb)=split(", ",$nametemp);
      ($garb,$lastname[$i])=split("\"",$lastname[$i]);
      ($lastname[$i],$garb)=split("\,",$lastname[$i]);
      ($garb,$firstname[$i])=split("$lastname[$i]",$nametemp);
      ($firstname[$i],$garb)=split("\"",$firstname[$i]);
      ($garb,$firstname[$i])=split("\, ",$firstname[$i]);
      print "$firstname[$i] $lastname[$i]\n";
      $i+=1;
    }
  $numstudents=$i;
}

sub RetrievePartsOfGrade {
  $i=0;
  open (PARTSOFGRADE, "<PartsOfGrade.txt") || die "Can't open configuration file PartsOfGrade.txt.\n";
  print "\nRetrieving parts of grade.\n";
  while(<PARTSOFGRADE>)
    {
      $line=$_;
      ($partofgrade[$i],$garb)=split("\t",$line);
      ($garb,$weight[$i])=split("$partofgrade[$i]",$line);
      ($weight[$i],$garb)=split("\n",$weight[$i]);
      ($garb,$weight[$i])=split("\t",$weight[$i]);
      ($garb,$gradeoutof[$i])=split("$partofgrade[$i]\t$weight[$i]\t",$line);
      ($gradeoutof[$i],$garb)=split("\n",$gradeoutof[$i]);
      if ($gradeoutof[$i] =~"-1") {
	print "$partofgrade[$i] $weight[$i]\%, out of variable points.\n";
      }
      else{
	print "$partofgrade[$i] $weight[$i]\%, out of $gradeoutof[$i] points.\n";
      }
      $i+=1;
    }
  $numpartsofgrade=$i;
  
  #now I'm going to add up the total percentage of the grade to be calculated and determine the relative weight.  This relative weight will actually be used when calculating the grade.
  $totalweight=0;
  for ($i=0;$i<$numpartsofgrade;$i++) {
    $totalweight+=$weight[$i];
  }
  for ($i=0;$i<$numpartsofgrade;$i++) {
    $relativeweight[$i]=$weight[$i]/$totalweight;
  }
  
}


sub RetrievePartOfGradeNames {
    #Reads in the headings over the grades
    for ($i=0; $i<$numpartsofgrade;$i++){
      if($line =~$partofgrade[$i]){
	$gradepart = $partofgrade[$i];
	$numgradepart = $i;
	($garb,$lineremaining)=split("$partofgrade[$i]\t",$line);
	@tempnames = split /\t{1}/, $lineremaining;
	$numnames = $#tempnames;
	for ($j=0;$j<=$numnames;$j++) {
	  ($temp,$garb)=split("\t",$tempnames[$j]);
	  $boolAverage[$i]=0;
	  if($temp=~"Average"){
	    $boolAverage[$i]=1;
	  }
	  else{
	    $names[$i][$j]=$temp;
	  }  
	}
	$numberofnames[$i]=$numnames;
      }
    }
}

sub RetrievePointsPossibleStrings {
  #Reads in the headings over the grades
  if($line =~"points possible"){
    ($garb,$lineremaining)=split("points possible",$line);
    ($garb,$lineremaining)=split("\"\t",$lineremaining);
    $pointspossiblestrings[$numgradepart]=$lineremaining;
  }
}

sub SetPointsPossible {
  if($boolPointsPossibleInitialized==0){
    for($i=0;$i<$numpartsofgrade;$i++){
      if($gradeoutof[$i]>0){
	for($j=0;$j<=$numberofnames[$i];$j++){
	  $pointspossible[$i][$j]=$gradeoutof[$i];
	}
      }
      else{
	@tempscores = split /\t{1}/, $pointspossiblestrings[$i];
	for($n=0;$n<=$numberofnames[$i];$n++){
	  $pointspossible[$i][$n]=$tempscores[$n];
	}
	
      }
    }
    $boolPointsPossibleInitialized=1;
  }
}

sub RetrieveGrades {
    #Reads in the actual grades
    for ($k=0;$k<$numstudents;$k++){
      if($line =~$fullname[$k]){
	($garb,$lineremaining)=split("$fullname[$k]\t",$line);
	#This line is an example of HORRIBLE syntax of perl
	#split /reg. expression/, $string returns an array of whatever was in the strings separated by whatever is in the reg. exp.
	#"\" is necessary because t is not intended to be literal.  This means a tab.  ("s" is any whitespace character.)
	#Here we only want exactly one whitespace character.  {1,} would mean at least one and {1,3} would mean between one and 3 whitespace characters.
	@tempgrades = split /\t{1}/, $lineremaining;
	for($m=0;$m<=$#tempgrades;$m++){
	  $grades[$k][$numgradepart][$m]=$tempgrades[$m];
	}
	}
	else{
	}
    }
}

sub Grade {
  #Ok so this got me fairly far.  I now have the relative weights of each part of the grade and I have the names of the students.  I now need to read in the grade sheet.  This will be tougher.
  #I'm going to read the grades into a 3-D array.
  open (GRADES, "<Grades.txt") || die "Can't open Grades.txt.\n";
  while(<GRADES>)
    {
      $line=$_;#This retrieves the line out of the file
      &RetrievePartOfGradeNames();
      &RetrieveGrades();
      &RetrievePointsPossibleStrings();
    }
}

sub CalculateStudentAverages {
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    #loop over students
    for($student=0;$student<$numstudents;$student++){
      $totalpointsearned=0;
      $totalpointspossible=0;
      #loop over grades
      for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
	if($grades[$student][$ptofgrade][$i] ne ""){
	  $totalpointsearned+=$grades[$student][$ptofgrade][$i];
	  $totalpointspossible+=$pointspossible[$ptofgrade][$i];
	}
      }
      if($totalpointspossible !=0){
	$studentavggrades[$student][$ptofgrade]=$totalpointsearned/$totalpointspossible; 
      }
    }
  }

}
sub CalculateClassAverages {
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    #loop over number of assignments
    for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
      #loop over students
      $numberofgrades=0;
      $pointsearned=0;
      for($student=0;$student<$numstudents;$student++){
	if($grades[$student][$ptofgrade][$i] ne ""){
	  $numberofgrades++;
	  $pointsearned+=$grades[$student][$ptofgrade][$i];
	}
      }
      if($numberofgrades !=0){
	$classavggrades[$ptofgrade][$i]=$pointsearned/$numberofgrades; 
      }
    }
  }
}
sub CalculateClassPartOfGradeAverages {
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    #loop over students
    $numberofgrades=0;
      $pointsearned=0;
    for($student=0;$student<$numstudents;$student++){
      if($studentavggrades[$student][$ptofgrade] ne ""){
	$numberofgrades++;
	$pointsearned+=$studentavggrades[$student][$ptofgrade];
      }
    }
    if($numberofgrades !=0){
      $classptofgradeavg[$ptofgrade]=$pointsearned/$numberofgrades; 
    }
  }
}


sub CalculateStudentStdDev {
use Math::Complex;
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    #loop over students
    for($student=0;$student<$numstudents;$student++){
      $variance=0;
      $numcalculated=0;
      #loop over grades
      for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
	if(($grades[$student][$ptofgrade][$i] ne "") && ($pointspossible[$ptofgrade][$i] !=0) ){
	  $variance+=($grades[$student][$ptofgrade][$i]/$pointspossible[$ptofgrade][$i]-$studentavggrades[$student][$ptofgrade])**2;
	  $numcalculated++;
	}
      }
      if($numcalculated >1){
	$variance=$variance/($numcalculated-1);
	$studentstddev[$student][$ptofgrade]=sqrt($variance);
      }
    }
  }

}
sub CalculateClassStdDev {
use Math::Complex;
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    #loop over number of assignments
    for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
      $variance=0;
      $numcalculated=0;
      #loop over students
      for($student=0;$student<$numstudents;$student++){
	if($grades[$student][$ptofgrade][$i] ne ""){
	  $variance+=($grades[$student][$ptofgrade][$i]-$classavggrades[$ptofgrade][$i])**2;
	  $numcalculated++;
	}
      }
      if($numcalculated >1){
	$variance=$variance/($numcalculated-1);
	$classstddev[$ptofgrade][$i]=sqrt($variance);
      }
    }
  }
}

sub CalculateClassPartOfGradeStdDev {
  use Math::Complex;
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    $variance=0;
    $numcalculated=0;
    #loop over students
    for($student=0;$student<$numstudents;$student++){
      if($studentavggrades[$student][$ptofgrade] ne ""){
	$variance+=($studentavggrades[$student][$ptofgrade]-$classptofgradeavg[$ptofgrade])**2;
	$numcalculated++;
      }
    }
    if($numcalculated >1){
      $variance=$variance/($numcalculated-1);
      $classptofgradestddev[$ptofgrade]=sqrt($variance);
    }
  }
}



sub CalculateStudentWeightedAverage {
  #loop over students
  for($student=0;$student<$numstudents;$student++){
    $sum=0;
    #loop over parts of grade
    for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
      $sum+=$studentavggrades[$student][$ptofgrade]*$relativeweight[$ptofgrade]
    }
    $studentweightedavg[$student]=$sum;
  }
}


sub CalculateClassWeightedAverage {
  $classweightedavg=0;
  #loop over students
  for($student=0;$student<$numstudents;$student++){
    $classweightedavg+=$studentweightedavg[$student];
  }
  if($numstudents!=0){
    $classweightedavg=$classweightedavg/$numstudents;
  }
}

sub CalculateClassWeightedStdDev {
use Math::Complex;
  $variance=0;
$classweightedstddev=0;
  #loop over students
  for($student=0;$student<$numstudents;$student++){
    $variance+=($studentweightedavg[$student]-$classweightedavg)**2;
  }
  if($numstudents>1){
    $variance=$variance/($numstudents-1);
    $classweightedstddev=sqrt($variance);
  }
}


sub RankWeightedGrades {
  %hashtosort={};
  @keyarray=@studentweightedavg;
  #define the values of the hash:
  for($i=0; $i<$numstudents;$i++){#$i is the value.  This is the student number
    $studentnumber=$i;
    $key=$keyarray[$i];
    #$hashtosort{$key} = [$i];#I think this will work... 
    #$hashtosort{$key} = [];#I think this will work... 
    push @{$hashtosort{$key}}, $studentnumber;
  }
  $j=0;
  $numgrades=0;
  for $key (sort {$b <=> $a} keys %hashtosort){
    $rank = $j+1;
    @studentnumber = @{$hashtosort{$key}};
    for($k=0;$studentnumber[$k] ne "";$k++){
      if($studentweightedavg[$studentnumber[$k]] ne ""){
	if($j<$numstudents){
	  $weightedaverageranks[$studentnumber[$k]]=$rank;
	}
	$numgrades++;
      }
      $j++;
    }
  }
  $weightedaverageranks[$numstudents+2]=$numgrades;
}
sub RankPartsOfGrades {
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){

    #retrieving the key array:
    #This has students' average grades, in student number order
    for($i=0; $i<$numstudents;$i++){#$i is the student number
      $gradearray[$i]=$studentavggrades[$i][$ptofgrade];
    }

    %hashtosort={};
    @keyarray=@gradearray;
    #define the values of the hash:
    for($i=0; $i<$numstudents;$i++){#$i is the value.  This is the student number
      $studentnumber=$i;
      $key=$keyarray[$i];
      #$hashtosort{$key} = [$i];#I think this will work... 
      #$hashtosort{$key} = [];#I think this will work... 
      push @{$hashtosort{$key}}, $studentnumber;
    }
    $j=0;
    $numgrades=0;
    for $key (sort {$b <=> $a} keys %hashtosort){
      $rank = $j+1;
      @studentnumber = @{$hashtosort{$key}};
      for($k=0;$studentnumber[$k] ne "";$k++){
	if($j<$numstudents){
	  if($gradearray[$studentnumber[$k]] ne ""){
	    $partofgraderanks[$studentnumber[$k]][$ptofgrade]=$rank;
	    $numgrades++;
	  }
	}
	$j++;
      }
    }

    $partofgraderanks[$numstudents+2][$ptofgrade]=$numgrades;

  }
}

sub RankAssignmentGrades {
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    #loop over number of assignments
    for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
      
      
      #retrieving the key array:
      #This has students' average grades, in student number order
      for($student=0; $student<$numstudents;$student++){#$student is the student number
	$gradearray[$student]=$grades[$student][$ptofgrade][$i];
      }
      
      %hashtosort={};
      @keyarray=@gradearray;
      #define the values of the hash:
      for($student=0; $student<$numstudents;$student++){#$student is the value.  This is the student number
	$studentnumber=$student;
	$key=$keyarray[$student];
	#$hashtosort{$key} = [$student];#I think this will work... 
	#$hashtosort{$key} = [];#I think this will work... 
	push @{$hashtosort{$key}}, $studentnumber;
      }
      $j=0;
$numgrades=0;
      for $key (sort {$b <=> $a} keys %hashtosort){
	$rank = $j+1;
	@studentnumber = @{$hashtosort{$key}};
	for($k=0;$studentnumber[$k] ne "";$k++){
	  if($j<$numstudents){
	    if($grades[$studentnumber[$k]][$ptofgrade][$i] ne ""){
	      $assignmentranks[$studentnumber[$k]][$ptofgrade][$i]=$rank;
	      $numgrades++;
	    }
	  }
	  $j++;
	}
      }

      $assignmentranks[$numstudents+2][$ptofgrade][$i]=$numgrades;
print 

    }
  }
}






#Subroutines for checking that the data have been entered correctly:
sub CheckFullnames {
print "Checking array with full names of students.  You have the following students:\n";
  for($i=0;$i<$numstudents;$i++){
    print "$fullname[$i]\n";
  }
}


sub CheckFirstnames {
print "Checking array with first names of students.  You have the following students:\n";
  for($i=0;$i<$numstudents;$i++){
    print "$firstname[$i]\n";
  }
}


sub CheckLastnames {
print "Checking array with last names of students.  You have the following students:\n";
  for($i=0;$i<$numstudents;$i++){
    print "$lastname[$i]\n";
  }
}

sub CheckPartsOfGrade {
print "Checking array with names of the parts of the grade.  Students must complete the following types of assignments:\n";
  for($i=0;$i<=$#partofgrade;$i++){
    if($gradeoutof[$i] != -1){
      print "$partofgrade[$i] is out of $gradeoutof[$i].  Its weight is $weight[$i], which is a relative weight of $relativeweight[$i].\n";
    }
    else{
      print "$partofgrade[$i] is out of a variable number of points.  Its weight is $weight[$i], which is a relative weight of $relativeweight[$i].\n";
    }
  }
}

sub CheckNumberOfNames {
print "Checking array with number of names of assignments.\n";
  for($i=0;$i<=$#partofgrade;$i++){
    print "There are $numberofnames[$i] $partofgrade[$i]assignments.\n";
  }
}

sub CheckNamesOfAssignments {
print "Checking the names of assignments.";
  for($i=0;$i<=$#partofgrade;$i++){
    print "\nThe assignments for $partofgrade[$i] are:\n";
    for($j=0;$j<$numberofnames[$i];$j++){
      print "$j. $names[$i][$j] ";
    }
  }
print "\n";
}

sub CheckGradeEntries {
	print "Reading grades for $gradepart, number $numgradepart\n";
}

sub CheckGrades {
  for($i=0;$i<=$#partofgrade;$i++){
    print "$partofgrade[$i]\n";
    for($k=0;$k<$numstudents;$k++){
      print "$fullname[$k]\t";
      for($j=0;$j<$numberofnames[$i];$j++){
	print "|$grades[$k][$i][$j]| ";
      }
      print "\n";
    }
    print "\n";
  }
	

}

sub CheckPointsPossible {
  print "\n";
    for($i=0;$i<$numpartsofgrade;$i++){
      print "$i:\n";
      for($j=0;$j<$numberofnames[$i];$j++){
	print "$pointspossible[$i][$j] ";
      }
      print "\n";

    }
}

sub CheckStudentAverages {
print "Checking student average grades:\n";
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$partofgrade[$ptofgrade]\n";
    #loop over students
    for($student=0;$student<$numstudents;$student++){
      print "$lastname[$student] $studentavggrades[$student][$ptofgrade]\n";
    }
  }

}


sub CheckClassAverages {
print "Checking class average grades:\n";
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$partofgrade[$ptofgrade]";
    #loop over assignments
    for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
      print "$classavggrades[$ptofgrade][$i] ";
    }
    print "\n";
  }

}
sub CheckStudentStdDev {
print "Checking student standard deviation:\n";
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$partofgrade[$ptofgrade]\n";
    #loop over students
    for($student=0;$student<$numstudents;$student++){
      print "$lastname[$student] $studentstddev[$student][$ptofgrade]\n";
    }
  }

}
sub CheckClassStdDev {
print "Checking class standard deviations:\n";
#loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$partofgrade[$ptofgrade]";
    #loop over assignments
    for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
      print "$classstddev[$ptofgrade][$i] ";
    }
    print "\n";
  }

}

sub CheckStudentWeightedAverage {
  #loop over students
print "Checking weighted average grades:\n";
  for($student=0;$student<$numstudents;$student++){
print "$lastname[$student] has a $studentweightedavg[$student]\n";
  }
}

sub CheckClassWeightedAverageAndStdDev {
print "Class average: $classweightedavg\t Class standard deviation: $classweightedstddev\n";
}

sub CheckWeightedGradeRanks {
  for($i=0; $i<$numstudents;$i++){#$i is the value.  This is the student number
    print "$lastname[$i] has rank $weightedaverageranks[$i]\/$weightedaverageranks[$numstudents+2]\n";
  }
}

sub CheckClassPartOfGradeAverages {
print "Checking averages for parts of the grade.\n";
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$partofgrade[$ptofgrade] $classptofgradeavg[$ptofgrade]\n";
  }
}

sub CheckClassPartOfGradeStdDev {
print "Checking class std dev for parts of the grade.\n";
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$partofgrade[$ptofgrade] $classptofgradestddev[$ptofgrade]\n";
  }
}

sub CheckPartsOfGradesRanks {
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$ptofgrade\n";
    for($i=0; $i<$numstudents;$i++){#$i is the value.  This is the student number
      print "$lastname[$i] has rank $partofgraderanks[$i][$ptofgrade]\/$partofgraderanks[$numstudents+2][$ptofgrade]\n";
    }
    print "\n";
  }
}
sub CheckAssignmentRanks {
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print "$ptofgrade\n";
    #loop over number of assignments
    for($student=0; $student<$numstudents;$student++){#$student is the value.  This is the student number
      print "$lastname[$student]\t";
      for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){

	print "$assignmentranks[$student][$ptofgrade][$i]\/$assignmentranks[$numstudents+2][$ptofgrade][$i]\t";
      }
      print "\n";
    }
    print "\n";
  }
}

sub WriteSummaryWebpage {
  #The following variables are necessary for writing webpages:
  $BeginWebpageBeforeTitle = "<html><head><meta content=\"text/html\; charset=ISO-8859-1\" http-equiv=\"content-type\"><title>";
  $BeginWebpageAfterTitle = "</title></head><body>\n";
  $BeginTable = "<table style=\"width: 100\%\; text-align\: left\;\" border=\"1\" cellpadding=\"2\" cellspacing=\"2\">\n<tbody>\n";
  $EndTable = "</tbody>\n</table>\n";
  $EndWebpage="<br>\n</body></html>\n";
  $BeginRow = "<tr>\n";
  $EndRow = "</tr>\n";
  $BeginCell = "<td style=\"vertical-align: top;\">";
  $BeginWideCellPart1 = "<td colspan=\"";#insert number of cells wide
  $BeginWideCellPart2 = "\" style=\"vertical-align: top;\">";
  $EndCell = "<br></td>\n";
  $BeginHeading = "<br>\n<div style=\"text-align: center;\"><big><big><big><big>";
  $EndHeading = "</big></big></big></big><br></div>";
  $BeginSubheading = "<br>\n<div style=\"text-align: center;\"><big><big>";
  $EndSubheading = "</big></big><br></div>";
  $BeginBold = "<span style=\"font-weight: bold;\">";
  $EndBold = "</span>";
  $BeginItalics = "<span style=\"font-style: italic;\">";
  $EndItalics = "</span>";
  
  open (SummaryWebpage, ">SummaryWebpage.html");
  print "Writing summary webpage\n";
  $Title="Summary Webpage";
  print SummaryWebpage "$BeginWebpageBeforeTitle$Title$BeginWebpageAfterTitle\n";
  print SummaryWebpage "$BeginHeading$BeginBold";
  print SummaryWebpage "Class Averages";
  print SummaryWebpage "$EndBold$EndHeading";
  print SummaryWebpage "$BeginTable";
  
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print SummaryWebpage "$BeginRow$BeginWideCellPart1";
    print SummaryWebpage "3$BeginWideCellPart2";

    #The following lines might cause some problems for Windows users.
    #This splits the quotes off of the name of the part of the grade if they are there and does nothing if they aren't.
    #Any problems could be solved by simply commenting out the next three lines.  It would lead to uglier output in some cases, but the code would run.
    ($garb,$data)=split("\"",$partofgrade[$ptofgrade]);
    ($data,$garb)=split("\"",$data);
    if($data ne ""){$partofgrade[$ptofgrade] = $data;}



    print SummaryWebpage "$BeginSubheading$BeginBold$partofgrade[$ptofgrade]$EndBold$EndSubheading";
    print SummaryWebpage "$EndCell$EndRow";
    
    print SummaryWebpage "$BeginRow";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "Assignment$EndBold$EndCell";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "Average$EndBold$EndCell";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "Standard Deviation$EndBold$EndCell";
    print SummaryWebpage "$EndRow";
    
    
    #loop over assignment number
    for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
      print SummaryWebpage "$BeginRow";
      print SummaryWebpage "$BeginCell";

    #The following lines might cause some problems for Windows users.
    #This splits the quotes off of the name of the part of the grade if they are there and does nothing if they aren't.
    #Any problems could be solved by simply commenting out the next three lines.  It would lead to uglier output in some cases, but the code would run.
      ($garb,$data)=split("\"",$names[$ptofgrade][$i]);
      ($data,$garb)=split("\"",$data);
      if($data ne ""){$names[$ptofgrade][$i] = $data;}

      print SummaryWebpage "$names[$ptofgrade][$i]";
      print SummaryWebpage "$EndCell";
      print SummaryWebpage "$BeginCell";
      if( $classavggrades[$ptofgrade][$i] ne ""){
	$value = sprintf("%.2f",$classavggrades[$ptofgrade][$i] );
	print SummaryWebpage "$value\/$pointspossible[$ptofgrade][$i]";
      }
      else{
	print SummaryWebpage "N\/A";
      }
      print SummaryWebpage "$EndCell";
      print SummaryWebpage "$BeginCell";
      if( $classavggrades[$ptofgrade][$i] ne ""){
	$value = sprintf("%.2f",$classstddev[$ptofgrade][$i]);
	print SummaryWebpage "$value";
      }
      else{
	print SummaryWebpage "N\/A";
      }
      print SummaryWebpage "$EndCell";
      print SummaryWebpage "$EndRow";
      
    }
    print SummaryWebpage "$BeginRow$BeginWideCellPart1";
    print SummaryWebpage "3$BeginWideCellPart2";
    print SummaryWebpage "$BeginItalics";
    $value1 = sprintf("%.2f",$classptofgradeavg[$ptofgrade]);
    $value2 = sprintf("%.2f",$classptofgradestddev[$ptofgrade]);
    
    print SummaryWebpage "Class Average: $value1 Class Standard Deviation: $value2 $EndItalics";
    print SummaryWebpage "$EndCell$EndRow";


  }

print SummaryWebpage "$EndTable";
print SummaryWebpage "$EndWebpage\n";
close(SummaryWebpage);
}

sub WriteStudentWebpage {
  my $student=$_[0];#Later this will be made an argument so I can loop over it
  #The following variables are necessary for writing webpages:
  $BeginWebpageBeforeTitle = "<html><head><meta content=\"text/html\; charset=ISO-8859-1\" http-equiv=\"content-type\"><title>";
  $BeginWebpageAfterTitle = "</title></head><body>\n";
  $BeginTable = "<table style=\"width: 100\%\; text-align\: left\;\" border=\"1\" cellpadding=\"2\" cellspacing=\"2\">\n<tbody>\n";
  $EndTable = "</tbody>\n</table>\n";
  $EndWebpage="<br>\n</body></html>\n";
  $BeginRow = "<tr>\n";
  $EndRow = "</tr>\n";
  $BeginCell = "<td style=\"vertical-align: top;\">";
  $BeginWideCellPart1 = "<td colspan=\"";#insert number of cells wide
  $BeginWideCellPart2 = "\" style=\"vertical-align: top;\">";
  $EndCell = "<br></td>\n";
  $BeginHeading = "<br>\n<div style=\"text-align: center;\"><big><big><big><big>";
  $EndHeading = "</big></big></big></big><br></div>";
  $BeginSubheading = "<br>\n<div style=\"text-align: center;\"><big><big>";
  $EndSubheading = "</big></big><br></div>";
  $BeginBold = "<span style=\"font-weight: bold;\">";
  $EndBold = "</span>";
  $BeginItalics = "<span style=\"font-style: italic;\">";
  $EndItalics = "</span>";
  open (SummaryWebpage, ">$lastname[$student]/GradesFor$lastname[$student].html");
  print "Writing summary webpage for $lastname[$student]\n";
  $Title="Grades for $firstname[$student] $lastname[$student]";
  print SummaryWebpage "$BeginWebpageBeforeTitle$Title$BeginWebpageAfterTitle\n";
  print SummaryWebpage "$BeginHeading$BeginBold";
  print SummaryWebpage "$Title";
  print SummaryWebpage "$EndBold$EndHeading";
  print SummaryWebpage "$BeginTable";
  
  #loop over parts of grade
  for($ptofgrade=0;$ptofgrade<=$#partofgrade;$ptofgrade++){
    print SummaryWebpage "$BeginRow$BeginWideCellPart1";
    print SummaryWebpage "5$BeginWideCellPart2";
    #($garb,$partofgrade[$ptofgrade])=split("\"",$partofgrade[$ptofgrade]);
    #($partofgrade[$ptofgrade],$garb)=split("\"",$partofgrade[$ptofgrade]);
    print SummaryWebpage "$BeginSubheading$BeginBold$partofgrade[$ptofgrade]$EndBold$EndSubheading";
    print SummaryWebpage "$EndCell$EndRow";
    
    print SummaryWebpage "$BeginRow";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "Assignment$EndBold$EndCell";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "$firstname[$student]\'s grade Grade$EndBold$EndCell";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "Class Average$EndBold$EndCell";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "Class Standard Deviation$EndBold$EndCell";
    print SummaryWebpage "$BeginCell$BeginBold";
    print SummaryWebpage "$firstname[$student]\'s rank on the assignment$EndBold$EndCell";
    print SummaryWebpage "$EndRow";
    
    
    #loop over assignment number
    for($i=0;$i<=($numberofnames[$ptofgrade]-$boolAverage[$ptofgrade]);$i++){
      #Cell with name of the assignment
      print SummaryWebpage "$BeginRow";
      print SummaryWebpage "$BeginCell";
      #($garb,$names[$ptofgrade][$i])=split("\"",$names[$ptofgrade][$i]);
      #($names[$ptofgrade][$i],$garb)=split("\"",$names[$ptofgrade][$i]);
      print SummaryWebpage "$names[$ptofgrade][$i]";
      print SummaryWebpage "$EndCell";

      #Cell with student's grade
      print SummaryWebpage "$BeginCell";
      if($grades[$student][$ptofgrade][$i] ne ""){
	$value = sprintf("%.2f",$grades[$student][$ptofgrade][$i] );
	print SummaryWebpage "$value\/$pointspossible[$ptofgrade][$i]";
      }
      else{
	print SummaryWebpage "N\/A";
      }
      print SummaryWebpage "$EndCell";

      #Cell with class average on the assignment
      print SummaryWebpage "$BeginCell";
      if( $classavggrades[$ptofgrade][$i] ne ""){
	$value = sprintf("%.2f",$classavggrades[$ptofgrade][$i] );
	print SummaryWebpage "$value\/$pointspossible[$ptofgrade][$i]";
      }
      else{
	print SummaryWebpage "N\/A";
      }
      print SummaryWebpage "$EndCell";

      #cell with class's standard deviation
      print SummaryWebpage "$BeginCell";
      if( $classavggrades[$ptofgrade][$i] ne ""){
	$value = sprintf("%.2f",$classstddev[$ptofgrade][$i]);
	print SummaryWebpage "$value";
      }
      else{
	print SummaryWebpage "N\/A";
      }
      print SummaryWebpage "$EndCell";

      #cell with student's rank
      print SummaryWebpage "$BeginCell";
      if( $assignmentranks[$student][$ptofgrade][$i] ne ""){
	print SummaryWebpage "$assignmentranks[$student][$ptofgrade][$i]\/$assignmentranks[$numstudents+2][$ptofgrade][$i]";
      }
      else{
	print SummaryWebpage "N\/A";
      }
      print SummaryWebpage "$EndCell";

      print SummaryWebpage "$EndRow";
      
    }
    print SummaryWebpage "$BeginRow";
    $value1 = sprintf("%.2f",$classptofgradeavg[$ptofgrade]*100);
    $value2 = sprintf("%.2f",$classptofgradestddev[$ptofgrade]*100);
    $value3 = sprintf("%.2f",$studentavggrades[$student][$ptofgrade]*100);
    
    print SummaryWebpage "$BeginCell$BeginItalics";
    print SummaryWebpage "Overall";
    print SummaryWebpage "$EndItalics$EndCell";
    
    print SummaryWebpage "$BeginCell$BeginItalics";
    print SummaryWebpage "$value3\%";
    print SummaryWebpage "$EndItalics$EndCell";
    
    print SummaryWebpage "$BeginCell$BeginItalics";
    print SummaryWebpage "$value1\%";
    print SummaryWebpage "$EndItalics$EndCell";
    
    print SummaryWebpage "$BeginCell$BeginItalics";
    print SummaryWebpage "$value2\%";
    print SummaryWebpage "$EndItalics$EndCell";
    
    print SummaryWebpage "$BeginCell$BeginItalics";
    print SummaryWebpage "$partofgraderanks[$student][$ptofgrade]\/$partofgraderanks[$numstudents+2][$ptofgrade]";
    print SummaryWebpage "$EndItalics$EndCell";

    print SummaryWebpage "$EndRow";


  }


  print SummaryWebpage "$BeginRow$BeginWideCellPart1";
  print SummaryWebpage "5$BeginWideCellPart2";
  print SummaryWebpage "$BeginSubheading$BeginBold";
  print SummaryWebpage "Weighted Average$EndBold$EndSubheading";
  print SummaryWebpage "$EndCell$EndRow";


  $value1 = sprintf("%.2f",$studentweightedavg[$student]*100);
  $value2 = sprintf("%.2f",$classweightedavg*100);
  $value3 = sprintf("%.2f",$classweightedstddev*100);

  print SummaryWebpage "$BeginRow$BeginWideCellPart1";
  print SummaryWebpage "2$BeginWideCellPart2";
  print SummaryWebpage "$firstname[$student]'s weighted average:\n$value1\%";
  print SummaryWebpage "$EndCell";

  print SummaryWebpage "$BeginCell";
  print SummaryWebpage "Class's weighted average:\n$value2\%";
  print SummaryWebpage "$EndCell";

  print SummaryWebpage "$BeginCell";
  print SummaryWebpage "Class's weighted average standard deviation:\n$value3\%";
  print SummaryWebpage "$EndCell";

  print SummaryWebpage "$BeginCell";
  print SummaryWebpage "$firstname[$student]'s overall rank in class:\n$weightedaverageranks[$student]\/$weightedaverageranks[$numstudents+2]";
  print SummaryWebpage "$EndCell";



print SummaryWebpage "$EndTable";
print SummaryWebpage "$EndWebpage\n";
close(SummaryWebpage);
}

sub WriteStudentSummaryWebpages {
  for($p=0; $p<$numstudents;$p++){#$i is the value.  This is the student number    
    &WriteStudentWebpage("$p");
  }
}

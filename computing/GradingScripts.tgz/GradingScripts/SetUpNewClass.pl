#!/usr/bin/perl
#unless($#ARGV==0){
#print "Wrong number of parameters.\n";
#die;
#}

#This line needs to be changed to the path to YOUR webpage.  This is the directory which will have the password protected folders in it.  You need the "/" at the end of the string in order for the program to work.

$path = "/home/nattrass/www/PLAYING/";


#summary of names of variables
#these are declared here so that they will be defined outside of the subroutines
#$fullname[]  array with full names of students
$fullname[0]=0;
#$firstname[]  array with first name of students
$firstname[0]=0;
#$lastname[]  array of last names
$lastname[0]=0;
#$numstudents  number of students, counting starts at 1
$numstudents=0;

&RetrieveStudentNames();
&MakeDirectories();
&MakeAccessFiles();
&SetPasswords();
&WriteAddUser();
&WriteRemoveUser();

sub MakeDirectories {
  #loop over students
  for(my $student=0;$student<$numstudents;$student++){
    system "mkdir -v $lastname[$student]";
  }
}


sub RetrieveStudentNames {
  #Getting list of student grades
  open (STUDENTLIST, "<StudentList.txt") || die "Can't open configuration file StudentList.txt.\n";
  print "Retrieving student names.";
  #print "  I will make password protected directories for the following students:\n";
  $i=0;
  while(<STUDENTLIST>)
    {
      $line=$_;
      ($fullname[$i],$garb)=split("\n",$line);
      $nametemp=$fullname[$i];
      ($lastname[$i],$garb)=split(", ",$nametemp);
      ($garb,$lastname[$i])=split("\"",$lastname[$i]);
      ($lastname[$i],$garb)=split("\,",$lastname[$i]);
      ($garb,$firstname[$i])=split("$lastname[$i]",$nametemp);
      ($firstname[$i],$garb)=split("\"",$firstname[$i]);
      ($garb,$firstname[$i])=split("\, ",$firstname[$i]);
      #print "$firstname[$i] $lastname[$i]\n";
      $i+=1;
    }
  $numstudents=$i;
}

sub MakeAccessFiles {
  #loop over students
  for(my $student=0;$student<$numstudents;$student++){
  open (HTACCESS, ">$lastname[$student]/.htaccess");
  print HTACCESS "AuthType Basic\n";
  print HTACCESS "AuthUserFile $path$lastname[$student]/.htpasswd\n";
  print HTACCESS "AuthName \"Access to grades for $firstname[$student] $lastname[$student]\"\n";
  print HTACCESS "require user $lastname[$student]\n";
  close(HTACCESS);

  }
}

sub SetPasswords {
  for(my $student=0;$student<$numstudents;$student++){
    print "Password for $lastname[$student]:\n";
    system "htpasswd -c $lastname[$student]/.htpasswd $lastname[$student]";
  }
}

sub WriteAddUser {
  open (ADDUSER, ">AddUser.pl");
  print ADDUSER "\#\!/usr/bin/perl\n";
  print ADDUSER "unless(\$\#ARGV==0){\n";
  print ADDUSER "print \"Wrong number of parameters.\\n\"\;\n";
  print ADDUSER "die\;\n";
  print ADDUSER "}\n";
  print ADDUSER "\$lastname = \$ARGV\[0\]\;\n";
  print ADDUSER "\n";
  print ADDUSER "print \"Adding user \$lastname\\n\"\;\n";
  print ADDUSER "\n";
  print ADDUSER "system \"mkdir -v \$lastname";
  print ADDUSER "\"\;\n";
  print ADDUSER "\n";
  print ADDUSER "  open \(HTACCESS, \">\$lastname/.htaccess\"\)\;\n";
  print ADDUSER "  print HTACCESS \"AuthType Basic\\n\"\;\n";
  print ADDUSER "  print HTACCESS \"AuthUserFile $path\$lastname/.htpasswd\\n\"\;\n";
  print ADDUSER "  print HTACCESS \"AuthName \\\"Access to grades for \$lastname\\\"\\n\"\;\n";
  print ADDUSER "  print HTACCESS \"require user \$lastname\\n\"\;\n";
  print ADDUSER "  close\(HTACCESS\)\;\n";
  print ADDUSER "\n";
  print ADDUSER "print \"Password for \$lastname:\\n\"\;\n";
  print ADDUSER "print \"htpasswd -c \$lastname/.htpasswd \$lastname\"\;\n";
  print ADDUSER "system \"htpasswd -c \$lastname/.htpasswd \$lastname\"\;\n";
  close(ADDUSER);

}

sub WriteRemoveUser {
  open (REMOVEUSER, ">RemoveUser.pl");
  print REMOVEUSER "\#\!/usr/bin/perl\n";
  print REMOVEUSER "unless(\$\#ARGV==0){\n";
  print REMOVEUSER "print \"Wrong number of parameters.\\n\"\;\n";
  print REMOVEUSER "die\;\n";
  print REMOVEUSER "}\n";
  print REMOVEUSER "\$lastname = \$ARGV\[0\]\;\n";
  print REMOVEUSER "\n";
  print REMOVEUSER "print \"Removing user \$lastname\\n\"\;\n";
  print REMOVEUSER "\n";
  print REMOVEUSER "system \"rm -r \$lastname";
  print REMOVEUSER "\"\;\n";
  close(REMOVEUSER);

}

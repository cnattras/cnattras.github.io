#!/usr/bin/perl
unless($#ARGV==0){
print "Wrong number of parameters.  You must tell me the username.\n";
print "Type ./ChangeUserPassword.pl username.\n";
die;
}
$lastname = $ARGV[0];

print "Changing password for $lastname\n";
print "Password for $lastname:\n";
#print "htpasswd -c $lastname/.htpasswd $lastname";
system "htpasswd $lastname/.htpasswd $lastname";

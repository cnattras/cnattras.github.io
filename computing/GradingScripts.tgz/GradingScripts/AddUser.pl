#!/usr/bin/perl
unless($#ARGV==0){
print "Wrong number of parameters.  You must tell me the username.\n";
print "Type ./AddUser.pl username\n";
die;
}
$lastname = $ARGV[0];

print "Adding user $lastname\n";

system "mkdir -v $lastname";

  open (HTACCESS, ">$lastname/.htaccess");
  print HTACCESS "AuthType Basic\n";
  print HTACCESS "AuthUserFile /home/nattrass/www/PLAYING/$lastname/.htpasswd\n";
  print HTACCESS "AuthName \"Access to grades for $lastname\"\n";
  print HTACCESS "require user $lastname\n";
  close(HTACCESS);

print "Password for $lastname:\n";
#print "htpasswd -c $lastname/.htpasswd $lastname";
system "htpasswd -c $lastname/.htpasswd $lastname";

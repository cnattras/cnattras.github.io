#!/usr/bin/perl
unless($#ARGV==0){
print "Wrong number of parameters.  You must tell me the username.\n";
print "Type ./RemoveUser.pl username\n;
die;
}
$lastname = $ARGV[0];

print "Removing user $lastname\n";

system "rm -r $lastname";

#!/bin/bash
sa-learn --spam --mbox ~/FalseNegatives
sa-learn --ham --mbox  ~/FalsePositives

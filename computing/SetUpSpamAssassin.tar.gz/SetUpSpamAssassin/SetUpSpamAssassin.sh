#!/bin/bash
cp .procmailrc ../.
spamassassin < sample-spam.txt
spamassasin -D < sample-nonspam.txt
cp SpamUpdate.sh ../.
